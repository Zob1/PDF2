# TODO

* Add JSFiddle example usage
* Expand on examples
* Add demo page to `immense.js.org/quill-drag-and-drop-module` & `quill-drag-and-drop-module.js.org`
* Fix weirdness of passing `{tag, attr}` as second param of `onDrop`
